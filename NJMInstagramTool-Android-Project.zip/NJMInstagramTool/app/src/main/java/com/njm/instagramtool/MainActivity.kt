package com.njm.instagramtool

import android.app.Activity
import android.os.Bundle
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 17, 27)
    private val panel = Color.rgb(30, 32, 48)
    private val pink = Color.rgb(220, 65, 160)
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(26), dp(20), dp(28))
        }
        scroll.addView(page)
        setContentView(scroll)

        page.addView(label("NJM", 16, pink, true))
        page.addView(label("Instagram Tool", 30, Color.WHITE, true))
        page.addView(label("Personal workflow dashboard", 14, 0xFFB8B9C8.toInt(), false))
        page.addView(space(20))

        val account = EditText(this).apply {
            hint = "Instagram username (optional)"
            setHintTextColor(0xFF999AAA.toInt())
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(panel)
        }
        page.addView(account, matchWrap())
        page.addView(space(14))

        section(page, "MESSAGE WORKSPACE")
        val dm = EditText(this).apply {
            hint = "Write a message for a person who expects to hear from you"
            minLines = 3
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF999AAA.toInt())
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(panel)
        }
        page.addView(dm, matchWrap())
        page.addView(space(8))
        page.addView(actionButton("Copy DM draft") { copy(dm.text.toString(), "DM draft") })

        page.addView(space(18))
        section(page, "COMMENT WORKSPACE")
        val comment = EditText(this).apply {
            hint = "Write a relevant comment"
            minLines = 2
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF999AAA.toInt())
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(panel)
        }
        page.addView(comment, matchWrap())
        page.addView(space(8))
        page.addView(actionButton("Copy comment draft") { copy(comment.text.toString(), "Comment draft") })

        page.addView(space(18))
        section(page, "FOLLOW-UP REMINDER")
        page.addView(label("Track a follow-up manually. The app does not send repeated messages.", 13, 0xFFB8B9C8.toInt(), false))
        page.addView(actionButton("Mark follow-up as needed") { setStatus("Follow-up marked. Review the conversation before contacting again.") })

        page.addView(space(18))
        section(page, "REPORT NOTES")
        page.addView(label("Keep a record of a genuine issue and review it before submitting a report in Instagram.", 13, 0xFFB8B9C8.toInt(), false))
        val notes = EditText(this).apply {
            hint = "Incident notes (date, link, what happened)"
            minLines = 3
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF999AAA.toInt())
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(panel)
        }
        page.addView(notes, matchWrap())
        page.addView(space(8))
        page.addView(actionButton("Copy report notes") { copy(notes.text.toString(), "Report notes") })

        page.addView(space(20))
        status = label("Ready • Drafts stay on this device until copied", 13, 0xFF7DE0B0.toInt(), false)
        page.addView(status)
        page.addView(space(10))
        page.addView(label("NJM Tool is a drafting and organization utility. It does not automate bulk DMs, comments, or reports.", 11, 0xFF85879A.toInt(), false))
    }

    private fun section(parent: LinearLayout, title: String) {
        parent.addView(label(title, 13, pink, true))
        parent.addView(space(8))
    }
    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
        }
    private fun actionButton(text: String, click: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(pink)
            setOnClickListener { click() }
        }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun matchWrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun setStatus(message: String) { status.text = message }
    private fun copy(value: String, label: String) {
        if (value.isBlank()) {
            Toast.makeText(this, "Write something first", Toast.LENGTH_SHORT).show()
            return
        }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, value))
        setStatus("$label copied to clipboard")
        Toast.makeText(this, "$label copied", Toast.LENGTH_SHORT).show()
    }
}
